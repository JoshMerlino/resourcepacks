# [Download](https://github.com/JoshMerlino/resourcepacks/blob/downloads/Better%20Entities.zip?raw=true)

![Screenshot 2021-08-21 235042](https://user-images.githubusercontent.com/31785395/130341440-8c44898d-5064-45b2-b6f3-68fc38196e8f.png)

Adds more animations to many mobs & entitys. *Forked from [animated-entitys](https://www.curseforge.com/minecraft/texture-packs/animated-entities)*

---
### Screenshots
![image](https://user-images.githubusercontent.com/31785395/130341245-cd1bd856-93ea-4472-a0f7-00d52a5ff602.png)
![image](https://user-images.githubusercontent.com/31785395/130341247-8083d18f-5fe2-4751-83c6-61fde24a16ab.png)
![image](https://user-images.githubusercontent.com/31785395/130341250-2e5e9166-100c-4f74-8bff-e8ab6aa59ef1.png)
![image](https://user-images.githubusercontent.com/31785395/130341252-28621cb3-a782-4643-b7a6-c8d62e79959c.png)
![2021-08-21_23 45 39](https://user-images.githubusercontent.com/31785395/130341362-d959a017-314b-44b7-b9fa-e905b9afa6f0.png)
![2021-08-21_23 46 26](https://user-images.githubusercontent.com/31785395/130341364-ba3705ec-6387-40a0-9f30-0b84e71333cf.png)
![2021-08-21_23 49 22](https://user-images.githubusercontent.com/31785395/130341404-521c7664-b9a1-4648-bdfe-7dde1a709d6c.png)

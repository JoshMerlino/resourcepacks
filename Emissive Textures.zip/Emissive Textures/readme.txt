Based on Glazer Vanilla Textures by Tstz for 1.16: https://www.planetminecraft.com/texture-pack/glazer-vanilla-4425773/ 
modified by nudiscoturkey

REQUIRES OPTIFINE TO WORK!



